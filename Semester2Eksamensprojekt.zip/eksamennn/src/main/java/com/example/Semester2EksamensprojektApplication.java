package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Semester2EksamensprojektApplication {

  public static void main(String[] args) {
    SpringApplication.run(Semester2EksamensprojektApplication.class, args);
  }

}
